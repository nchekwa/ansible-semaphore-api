# ansible-semaphore-api
[![OpenAPI](https://github.com/nchekwa/ansible-semaphore-api/actions/workflows/openapi-generator.yml/badge.svg)](https://github.com/nchekwa/ansible-semaphore-api/actions/workflows/openapi-generator.yml)
[![pytest](https://github.com/nchekwa/ansible-semaphore-api/actions/workflows/python-pytest.yml/badge.svg?branch=main)](https://github.com/nchekwa/ansible-semaphore-api/actions/workflows/python-pytest.yml)

ansible-semaphore Python API Lib<br>
https://github.com/ansible-semaphore/semaphore
