# flake8: noqa

# import apis into api package
from semaphore_api.api.authentication_api import AuthenticationApi
from semaphore_api.api.default_api import DefaultApi
from semaphore_api.api.integration_api import IntegrationApi
from semaphore_api.api.project_api import ProjectApi
from semaphore_api.api.projects_api import ProjectsApi
from semaphore_api.api.schedule_api import ScheduleApi
from semaphore_api.api.user_api import UserApi

